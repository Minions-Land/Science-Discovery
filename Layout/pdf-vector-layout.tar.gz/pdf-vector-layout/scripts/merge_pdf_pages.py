#!/usr/bin/env python3
"""
Merge multiple PDF pages into a composite, with optional vector white masks
to hide source-side labels that conflict with the composite's labels.

Use this when:
    - You have a base composite PDF (e.g. figureX_v16 layout)
    - You want to paste a row from another PDF (e.g. wet_source) into it
    - The source PDF has its own panel letters that conflict with the composite's
    - Everything must remain vector-editable

This is the v16 session's exact workflow, generalized.

Usage:
    python merge_pdf_pages.py

Before running:
    1. Render both source and composite to PNG at 150 DPI
    2. Measure where the source row sits (in source PDF points)
    3. Measure where it should land in the composite (in composite PDF points)
    4. Identify the source's conflicting labels (their bounding region in points)
    5. Edit the constants in the "Configuration" section
    6. Run the script and render the output to PNG to verify
"""

from copy import copy
from pathlib import Path
from pypdf import PdfReader, PdfWriter, PageObject, Transformation
from reportlab.pdfgen import canvas
from reportlab.lib.colors import white

# ============================================================================
# Configuration — EDIT THESE
# ============================================================================

# Base composite (the "destination") and source (the row to paste in)
COMPOSITE_PDF = Path("composite_base.pdf")
SOURCE_PDF = Path("source_row.pdf")
OUTPUT_PDF = Path("composite_final.pdf")

# Source region (in source PDF points) — the part you want to paste in
SOURCE_REGION_LEFT = 0.0
SOURCE_REGION_BOTTOM = 100.0
SOURCE_REGION_RIGHT = 595.28  # full width
SOURCE_REGION_TOP = 350.0

# Destination position (in composite PDF points) — where the source's
# bottom-left corner should land in the composite
DEST_X = 0.0
DEST_Y = 50.0

# Optional scale (1.0 = no scaling)
SCALE = 1.0

# Vector white masks (in composite PDF points) to hide source-side labels
# Each mask is (x, y, width, height); fill is white, no stroke
# Constrain y so the mask doesn't bleed into the composite's own labels
MASKS = [
    # Example: hide the source's 'e/f/g/h/i' letters at the top of the pasted region
    # (x, y, width, height)
    # (0, 320, 595.28, 30),
]

# ============================================================================
# Script
# ============================================================================

def main():
    composite_reader = PdfReader(str(COMPOSITE_PDF))
    source_reader = PdfReader(str(SOURCE_PDF))

    composite_page = composite_reader.pages[0]
    source_page = source_reader.pages[0]

    W = float(composite_page.mediabox.right)
    H = float(composite_page.mediabox.top)

    print(f"Composite: {COMPOSITE_PDF} ({W:.2f} × {H:.2f} pt)")
    print(f"Source: {SOURCE_PDF}")
    print(f"Source region: ({SOURCE_REGION_LEFT}, {SOURCE_REGION_BOTTOM}) to "
          f"({SOURCE_REGION_RIGHT}, {SOURCE_REGION_TOP})")
    print(f"Destination: ({DEST_X}, {DEST_Y}), scale={SCALE}")
    print(f"Masks: {len(MASKS)}")

    # Step 1: Crop the source page to the desired region
    def clone_with_box(src_page, left, bottom, right, top):
        p = copy(src_page)
        p.cropbox.lower_left = (left, bottom)
        p.cropbox.upper_right = (right, top)
        p.mediabox.lower_left = (left, bottom)
        p.mediabox.upper_right = (right, top)
        return p

    cropped_source = clone_with_box(
        source_page,
        SOURCE_REGION_LEFT,
        SOURCE_REGION_BOTTOM,
        SOURCE_REGION_RIGHT,
        SOURCE_REGION_TOP,
    )

    # Step 2: Compute the translation
    # We want the cropped region's bottom-left to land at (DEST_X, DEST_Y)
    # The cropped region's bottom-left is at (SOURCE_REGION_LEFT, SOURCE_REGION_BOTTOM)
    tx = DEST_X - SOURCE_REGION_LEFT * SCALE
    ty = DEST_Y - SOURCE_REGION_BOTTOM * SCALE

    transformation = Transformation().scale(SCALE).translate(tx=tx, ty=ty)

    # Step 3: Generate vector white masks (if any)
    if MASKS:
        mask_pdf_path = Path("tmp_masks.pdf")
        c = canvas.Canvas(str(mask_pdf_path), pagesize=(W, H))
        c.setFillColor(white)
        c.setStrokeColor(white)
        for x, y, w, h in MASKS:
            c.rect(x, y, w, h, fill=1, stroke=0)
        c.save()

        mask_reader = PdfReader(str(mask_pdf_path))
        mask_page = mask_reader.pages[0]
    else:
        mask_page = None

    # Step 4: Compose
    # Order: composite (bottom) → source (middle) → masks (top, to hide source labels)
    # But masks must be applied to the composite layer, not on top of source!
    # So actually: composite → masks → source (source goes on top of masks)
    # No wait: masks need to hide source labels, so masks go ON TOP of source.
    # Re-reading the v16 session: masks were drawn AFTER the source was placed,
    # so masks cover the source's labels but not the composite's.

    # Start with the composite as the base
    final_page = composite_page

    # Paste the source on top
    final_page.merge_transformed_page(cropped_source, transformation)

    # Apply masks on top of the source (but not over the composite's labels)
    if mask_page:
        final_page.merge_page(mask_page)

    # Step 5: Write output
    writer = PdfWriter()
    writer.add_page(final_page)
    OUTPUT_PDF.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_PDF.open('wb') as f:
        writer.write(f)

    # Clean up temp mask file
    if MASKS and mask_pdf_path.exists():
        mask_pdf_path.unlink()

    print(f"\nOutput: {OUTPUT_PDF}")
    print(f"File size: {OUTPUT_PDF.stat().st_size / 1024:.1f} KB")
    print("\nNext steps:")
    print(f"  1. Render to PNG: pdftocairo -png -r 150 {OUTPUT_PDF} preview")
    print(f"  2. Verify text: pdftotext {OUTPUT_PDF} -")
    print(f"  3. Check: only one set of panel letters, no clipping, correct spacing")
    print(f"  4. If user wants SVG/PNG: pdftocairo -svg {OUTPUT_PDF} {OUTPUT_PDF.with_suffix('.svg')}")

if __name__ == "__main__":
    main()
