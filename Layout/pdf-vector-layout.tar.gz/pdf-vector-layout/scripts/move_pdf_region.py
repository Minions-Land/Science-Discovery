#!/usr/bin/env python3
"""
Move a region of a PDF page to a new location, preserving vectors.

This is the simplest case: single source PDF, translate/crop only.
Uses pure pypdf.

Usage:
    python move_pdf_region.py

Before running:
    1. Render the source PDF to PNG at 150 DPI
    2. Measure the region you want to move (in pixels)
    3. Convert pixel coordinates to PDF points using the helper below
    4. Edit the constants in the "Configuration" section
    5. Run the script
    6. Render the output to PNG and verify
"""

from copy import copy
from pathlib import Path
from pypdf import PdfReader, PdfWriter, PageObject, Transformation

# ============================================================================
# Configuration — EDIT THESE
# ============================================================================

# Input/output paths
INPUT_PDF = Path("source.pdf")
OUTPUT_PDF = Path("output_shifted.pdf")

# Page geometry (read from the source PDF, or measure from the rendered PNG)
# For A4: WIDTH = 595.28, HEIGHT = 841.89
# For US Letter: WIDTH = 612, HEIGHT = 792
WIDTH = 595.28
HEIGHT = 841.89

# Region to move (in PDF points, origin at bottom-left, y-axis points up)
# Example: move the bottom row (y = 100–300) down by 50 pt
REGION_BOTTOM = 100.0  # bottom edge of the region to move
REGION_TOP = 300.0     # top edge of the region to move
SHIFT_Y = -50.0        # negative = move down, positive = move up

# If you measured in pixels, use this helper to convert:
def y_px_to_pt(y_px, img_height_px, pdf_height_pt):
    """Convert pixel y-coordinate to PDF points (y-axis points up)."""
    return pdf_height_pt * (1 - y_px / img_height_px)

# Example: rendered at 150 DPI, page is 841.89 pt tall, region starts at pixel 600
# REGION_TOP = y_px_to_pt(600, 1754, 841.89)

# ============================================================================
# Script
# ============================================================================

def main():
    reader = PdfReader(str(INPUT_PDF))
    page = reader.pages[0]

    # Read actual page size from the PDF
    W = float(page.mediabox.right)
    H = float(page.mediabox.top)

    print(f"Source: {INPUT_PDF}")
    print(f"Page size: {W:.2f} × {H:.2f} pt")
    print(f"Moving region: y ∈ [{REGION_BOTTOM:.2f}, {REGION_TOP:.2f}]")
    print(f"Shift: {SHIFT_Y:+.2f} pt")

    # Create a blank page
    new_page = PageObject.create_blank_page(width=W, height=H)

    # Clone the page with different crop boxes
    def clone_with_box(src_page, left, bottom, right, top):
        p = copy(src_page)
        p.cropbox.lower_left = (left, bottom)
        p.cropbox.upper_right = (right, top)
        p.mediabox.lower_left = (left, bottom)
        p.mediabox.upper_right = (right, top)
        return p

    # Part 1: content above the region (stays in place)
    if REGION_TOP < H:
        p_top = clone_with_box(page, 0, REGION_TOP, W, H)
        new_page.merge_transformed_page(p_top, Transformation())

    # Part 2: the region to move
    p_region = clone_with_box(page, 0, REGION_BOTTOM, W, REGION_TOP)
    new_page.merge_transformed_page(
        p_region,
        Transformation().translate(tx=0, ty=SHIFT_Y)
    )

    # Part 3: content below the region (stays in place)
    if REGION_BOTTOM > 0:
        p_bottom = clone_with_box(page, 0, 0, W, REGION_BOTTOM)
        new_page.merge_transformed_page(p_bottom, Transformation())

    # Write output
    writer = PdfWriter()
    writer.add_page(new_page)
    OUTPUT_PDF.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_PDF.open('wb') as f:
        writer.write(f)

    print(f"Output: {OUTPUT_PDF}")
    print(f"File size: {OUTPUT_PDF.stat().st_size / 1024:.1f} KB")
    print("\nNext steps:")
    print(f"  1. Render to PNG: pdftocairo -png -r 150 {OUTPUT_PDF} preview")
    print(f"  2. Verify text: pdftotext {OUTPUT_PDF} -")
    print(f"  3. Check that the region moved by {SHIFT_Y:+.2f} pt")

if __name__ == "__main__":
    main()
